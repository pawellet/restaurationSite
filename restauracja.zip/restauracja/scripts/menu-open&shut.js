//menu appears when you click on hamburger

const burgerMenu = document.querySelector(".burger-svg");

burgerMenu.addEventListener("click", () => {
    const nav = document.querySelector(".nav__container-m");


    if (nav.classList.contains("hide")) {
        nav.classList.remove("hide");


    } else {
        nav.classList.add("hide")
    }
})

//shut the menu panel
document.querySelector(".nav__x-sign-m").addEventListener("click", () => {

    const nav = document.querySelector(".nav__container-m");
    const start = document.querySelector(".nav__list-dropdown-m");

    nav.classList.add("hide");
    start.classList.add("dropdown-close");
})

//show dropdown menu when you click on li data="start"
document.querySelector("[data='start-m']").addEventListener("click", () => {

    const mobile = document.querySelector(".nav__list-dropdown-m");

    if (mobile.classList.contains("dropdown-close")) {
        mobile.classList.remove("dropdown-close");
    } else {
        mobile.classList.add("dropdown-close");
    }
})

document.querySelector("[data='start']").addEventListener("click", () => {

    const desktop = document.querySelector(".navigation__list-dropdown");

    if (desktop.classList.contains("dropdown-close")) {
        desktop.classList.remove("dropdown-close");
    } else {
        desktop.classList.add("dropdown-close");
    }
})




