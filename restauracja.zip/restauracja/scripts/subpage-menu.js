


const menuItem = document.querySelectorAll(".subpage-menu-food-item");

const burgery = document.querySelector("ul[data='burgery']");
const zapiekanki = document.querySelector("ul[data='zapiekanki']");
const dodatki = document.querySelector("ul[data='dodatki']");
const napoje = document.querySelector("ul[data='napoje']");
const listItem = [burgery, zapiekanki, dodatki, napoje];

const rootStyle = document.querySelector(":root");
const computedStyles = window.getComputedStyle(rootStyle);
const colorStyle = computedStyles.getPropertyValue('--nav-m-bg');


const checkOpenedLists = () => {
    listItem.forEach((listitem, index) => {
        if (listitem.classList.contains("dropdown-close")) {
            console.log("contain");

        } else {
            listitem.classList.add("dropdown-close");
            menuItem[index].style.setProperty('--caret-down', 'black');
            menuItem[index].style.borderBottom = `1px solid ${colorStyle}`;

        }
    });
}

let windowWidth = window.innerWidth;


const mobileList = () => {


    menuItem.forEach((item) => {
        const itemDataset = item.getAttribute("data");
        const arrow = item.querySelector(".subpage-menu-food-item-arrow-down");


        if (itemDataset === "burgery") {

            item.addEventListener("click", () => {


                if (burgery.classList.contains("dropdown-close")) {
                    burgery.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    arrow.style.transform = "rotate(180deg)";
                } else {
                    burgery.classList.add("dropdown-close");
                    arrow.style.transform = "rotate(0)";
                    item.style.setProperty('--caret-down', 'black');


                }
            })
        }
        if (itemDataset === "zapiekanki") {

            item.addEventListener("click", () => {


                if (zapiekanki.classList.contains("dropdown-close")) {
                    zapiekanki.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    arrow.style.transform = "rotate(180deg)";
                } else {
                    zapiekanki.classList.add("dropdown-close");
                    arrow.style.transform = "rotate(0)";
                    item.style.setProperty('--caret-down', 'black');
                }
            })
        }
        if (itemDataset === "dodatki") {

            item.addEventListener("click", () => {


                if (dodatki.classList.contains("dropdown-close")) {
                    dodatki.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    arrow.style.transform = "rotate(180deg)";
                } else {
                    dodatki.classList.add("dropdown-close");
                    arrow.style.transform = "rotate(0)";
                    item.style.setProperty('--caret-down', 'black');
                }
            })
        }
        if (itemDataset === "napoje") {


            item.addEventListener("click", () => {


                if (napoje.classList.contains("dropdown-close")) {
                    napoje.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    arrow.style.transform = "rotate(180deg)";
                } else {
                    napoje.classList.add("dropdown-close");
                    arrow.style.transform = "rotate(0)";
                    item.style.setProperty('--caret-down', 'black');
                }
            })
        }

    })

};

const desktopList = () => {

    menuItem.forEach((item) => {
        const itemDataset = item.getAttribute("data");

        if (itemDataset === "burgery") {


            item.addEventListener("click", () => {

                checkOpenedLists()

                if (burgery.classList.contains("dropdown-close")) {
                    burgery.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    item.style.borderBottom = `3px solid ${colorStyle}`;
                } else {
                    burgery.classList.add("dropdown-close");
                    item.style.setProperty('--caret-down', 'black');
                    item.style.borderBottom = `1px solid ${colorStyle}`;


                }
            })
        }
        if (itemDataset === "zapiekanki") {

            item.addEventListener("click", () => {

                checkOpenedLists()

                if (zapiekanki.classList.contains("dropdown-close")) {
                    zapiekanki.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    item.style.borderBottom = `3px solid ${colorStyle}`;

                } else {
                    zapiekanki.classList.add("dropdown-close");
                    item.style.setProperty('--caret-down', 'black');
                    item.style.borderBottom = `1px solid ${colorStyle}`;

                }
            })
        }
        if (itemDataset === "dodatki") {

            item.addEventListener("click", () => {

                checkOpenedLists()

                if (dodatki.classList.contains("dropdown-close")) {
                    dodatki.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    item.style.borderBottom = `3px solid ${colorStyle}`;

                } else {
                    dodatki.classList.add("dropdown-close");
                    item.style.setProperty('--caret-down', 'black');
                    item.style.borderBottom = `1px solid ${colorStyle}`;

                }
            })
        }
        if (itemDataset === "napoje") {


            item.addEventListener("click", () => {

                checkOpenedLists()


                if (napoje.classList.contains("dropdown-close")) {
                    napoje.classList.remove("dropdown-close");
                    item.style.setProperty('--caret-down', colorStyle);
                    item.style.borderBottom = `3px solid ${colorStyle}`;

                } else {
                    napoje.classList.add("dropdown-close");
                    item.style.setProperty('--caret-down', 'black');
                    item.style.borderBottom = `1px solid ${colorStyle}`;

                }
            })
        }

    })
}

document.addEventListener("DOMContentLoaded", () => {
    if (windowWidth < 1000) {
        mobileList()
    } else if (windowWidth >= 1000) {
        desktopList()
        burgery.classList.remove("dropdown-close");
        menuItem[0].style.borderBottom = `3px solid ${colorStyle}`;
    }
})


let doIt;

window.onresize = (e) => {

    clearTimeout(doIt);

    doIt = setTimeout(() => {

        windowWidth = e.target.innerWidth;

        if (windowWidth < 1000) {

            window.location.href = window.location.href;


        } else if (windowWidth >= 1000) {

            window.location.href = window.location.href;

        }


    }, 250)

}